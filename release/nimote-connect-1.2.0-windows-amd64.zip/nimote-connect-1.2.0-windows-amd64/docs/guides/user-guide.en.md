# Install and use Nimote Connect

[中文](user-guide.md)

## Install or upgrade

Obtain the commercial bundle for your platform and the SHA-256 checksum from the distributor. Verify the archive, extract it, and run this command from the extracted directory as your desktop user:

```sh
./install.sh
```

The bundle installs Connect and Host. macOS requires an active desktop login. Linux requires a systemd user session. After installing a desktop bundle, run `~/.local/bin/nimoteconn gui --connect` to choose a connection method. The CLI bundle prompts for approval on first install. Use `--defer-login` to install for existing SSH or bind later, or `--login` to pair during desktop installation. Upgrades retain an existing binding. Use `--skip-login` when an existing binding is required.

For Windows x64 or ARM64, extract the CLI ZIP and run `.\install.ps1` in PowerShell as the logged-in user. Use `-SkipLogin` with an existing binding, `-DeferLogin` to bind later, or `-Uninstall` to remove the services. Scheduled tasks run while this user is logged in. The CLI is at `%LOCALAPPDATA%\NimoteConnect\nimoteconn.exe`. Before enabling public remote access, start Windows OpenSSH Server on TCP port 22 and confirm that this user can read its public host keys.

To switch from NimoteHost Community, run `./install.sh` as the same user who installed Community. The installer checks the existing Host and running tasks before requesting pairing. Wait for any running work to finish. A standard installation switches to the Connect-managed Host in place and retains Host data, session history and the existing SSH entry. Use the Connect installer for subsequent updates.

Use the new commercial installer to upgrade. Active Host tasks block replacement. If installation fails, consult the reported backup location and recovery result.

## Connect

Existing SSH and personal Tailscale connections use the same SSH account and Host RPC. The SSH command is available at `~/.local/bin/nimotehost`. Open `~/Applications/NimoteConn.app` on macOS or run `~/.local/bin/nimoteconn gui --connect` with a Linux desktop bundle.

For internet access or to sync a personal Tailscale connection, bind the computer from **Connect** or run `nimoteconn login`. In NimoteCode on your phone, enter the device code and approve the computer. Both devices must use the same Nimote service.

Internet access starts off by default. After binding, select **Enable remote access** or run `nimoteconn remote-access enable`. On macOS, turn on **Remote Login** under **System Settings → General → Sharing**. On Linux, start the local OpenSSH server. When the computer shows **Registered with Nimote**, select it in NimoteCode, independently confirm the SSH host fingerprint and open a Host session to verify connectivity.

## Manage the installation

| Action | Command |
| --- | --- |
| Check both services | `~/.local/bin/nimoteconn status` and `~/.local/bin/nimoteconn host status` |
| View or copy diagnostics | `nimoteconn doctor`, or use the diagnostics controls in **NimoteConn → Connect** |
| Check remote access | `nimoteconn remote-access status` |
| Enable or disable remote access | `nimoteconn remote-access enable` or `nimoteconn remote-access disable` |
| Restart Connect | `~/.local/bin/nimoteconn restart` |
| Remove both services and binaries, keeping binding and Host data | Run `./install.sh --uninstall` from the extracted bundle |
| Revoke the local Connect binding | `~/.local/bin/nimoteconn logout` |

Remote-access status shows the setting, registration progress, and detected problems. Turning off internet access restarts Connect and can interrupt sessions using it. Unbinding stops Connect before asking Nimote to revoke the binding. If revocation cannot be confirmed, retry unbinding. The uninstaller retains the binding and Host data. To permanently retire a device, finish unbinding before uninstalling.

The device list in NimoteCode shows the reported host version and, for an offline device, the last time it reported in. The diagnostics report includes Connect and Host status, registration, the current process's most recent cloud contact when available, and the local SSH port check. The Connect page lets you preview the report before sharing it with support.
