# NimoteHost 2.5.0+connect.0.2.0-local.8b06897

[English](README.md) | **简体中文**

CLI · linux/arm64

[NimoteCode](https://github.com/mobiledevloperlab/nimotecode) 的主机端配套服务，
也可通过脚本或第三方客户端独立使用。当前为开发预览版。

## 安装

解压完整归档后，在该目录以普通用户执行，无需 sudo：

```sh
sh scripts/install.sh
```

无需安装 Go。安装器验证 SHA256SUMS，将完整包复制到固定用户目录并启动后台服务。
升级保留数据和凭据，有活动任务时拒绝升级。请保持分发文件完整，保留许可证文件，
不要修改 SHA256SUMS 覆盖的内容。

如需直接以前台 CLI 运行：

```sh
./nimotehost start
```

## 连接与管理

在 NimoteCode 中使用同一系统账号的既有 SSH 连接。SSH 和 Agent CLI 需单独安装、认证。
Host 只监听本机回环地址。客户端断开不会停止任务；Host 或系统重启不会恢复任务进程。
可使用 nimotehost status、stop 或 restart 管理 Host。

## 文档与声明

- [完整文档](https://github.com/mobiledevloperlab/nimotehost/blob/master/README.zh-CN.md)
- [客户端接入](https://github.com/mobiledevloperlab/nimotehost/blob/master/docs/client-api.md)
- [安全与凭据轮换](https://github.com/mobiledevloperlab/nimotehost/blob/master/SECURITY.zh-CN.md)
- [许可证](LICENSE) · [NOTICE](NOTICE) · [第三方声明](THIRD_PARTY_NOTICES.zh-CN.md)

BUILD.json 和 MODULES.json 记录 CLI 构建信息；桌面包另附 GUI-MODULES.json 和 licenses-gui/。
SHA256SUMS 覆盖包内文件，相邻 .sha256 校验下载归档；校验和不能验证发布者身份。
