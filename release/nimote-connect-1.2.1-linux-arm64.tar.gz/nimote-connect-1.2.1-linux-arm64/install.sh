#!/usr/bin/env bash
# Install a Nimote Connect release bundle for the current user.
set -euo pipefail

usage() {
  cat <<'EOF'
Usage: ./install.sh [--skip-login | --login | --defer-login | --uninstall]

Installs the nimoteconn command to ~/.local/bin and adds the NimoteConn
launcher when the bundle includes the desktop app. It starts two separate per-user
services. Desktop bundles let you choose a connection method after installation.
CLI-only bundles request device approval during first installation. Existing bindings
and service environment settings are retained; legacy executable paths need migration.

Options:
  --skip-login  Keep an existing binding during an upgrade. The script still
                installs the binary and refreshes the background service.
  --login       Request device approval during first installation, including desktop bundles.
  --defer-login Install before binding. Use existing SSH or bind later.
  --uninstall   Remove both services and binaries. Retain binding and Host data.
  -h, --help    Show this help.

Run this script as the desktop user, without sudo. During login, approve the
device code in the NimoteCode app, then return to this terminal.
EOF
}

mode=default
while (($# > 0)); do
  case "$1" in
    -h|--help) usage; exit 0 ;;
    --skip-login|--login|--defer-login|--uninstall)
      if [[ "$mode" != default && "$mode" != "$1" ]]; then usage >&2; exit 2; fi
      mode="$1"; shift ;;
    *) echo "unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
  echo "Run this installer as your normal desktop user, without sudo." >&2
  exit 1
fi

case "$(uname -s)" in
  Darwin|Linux) ;;
  *)
    echo "Nimote Connect supports macOS and Linux only." >&2
    exit 1
    ;;
esac

bundle_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source_binary="$bundle_dir/nimote-connect"
source_host="$bundle_dir/host/nimotehost"
if [[ ! -f "$source_binary" || ! -f "$source_host" ]]; then
  echo "A required executable is missing from this release bundle." >&2
  exit 1
fi
# Verify the package before executing any bundled program. Checksums detect
# corruption; obtain the archive checksum/signature through a trusted channel.
if [[ ! -f "$bundle_dir/SHA256SUMS" ]]; then
  echo "Missing SHA256SUMS; obtain a complete release bundle." >&2; exit 1
fi
(
  cd "$bundle_dir"
  if command -v sha256sum >/dev/null; then sha256sum -c SHA256SUMS >/dev/null
  else shasum -a 256 -c SHA256SUMS >/dev/null; fi
)
if ! "$source_binary" version >/dev/null || [[ "$("$source_host" version)" != nimotehost\ *+connect.* ]]; then
  echo "This binary cannot run on this computer. Download the matching release bundle." >&2
  exit 1
fi

install_dir="${HOME:?HOME is required}/.local/bin"
target_binary="$install_dir/nimote-connect"
connect_command="$install_dir/nimoteconn"
app_link="$HOME/Applications/NimoteConn.app"
app_target="$HOME/.local/share/nimotehost/NimoteConn.app"
legacy_app_target="$HOME/.local/share/nimotehost/NimoteHost.app"
legacy_app_links=("$HOME/Applications/NimoteConnect.app" "$HOME/Applications/NimoteHost.app")
platform="$(uname -s)"
if [[ "$platform" == Linux ]]; then
  app_link="$install_dir/nimoteconn-gui"
  app_target="$HOME/.local/share/nimotehost/nimoteconn-gui"
  config_dir="${XDG_CONFIG_HOME:-$HOME/.config}"
  service_file="$config_dir/systemd/user/nimote-connect.service"
  systemctl --user show-environment >/dev/null || {
    echo "A working systemd user session is required. Ask your administrator to configure it." >&2; exit 1;
  }

else
  config_dir="$HOME/Library/Application Support"
  service_file="$HOME/Library/LaunchAgents/com.nimote.connect.plist"
  launchctl print "gui/$(id -u)" >/dev/null || {
    echo "Log into the Mac desktop before installing." >&2; exit 1;
  }
fi
state_dir="$HOME/.local/share/nimote-connect"
umask 077
mkdir -p "$install_dir" "$state_dir/backups"
install_lock="$state_dir/install.lock"
if ! mkdir "$install_lock"; then
  echo "Another bundle operation may be running. Check $install_lock before retrying." >&2
  exit 1
fi
trap 'rmdir "$install_lock"' EXIT
trap 'exit 1' HUP INT TERM
existing_service=false
if [[ -f "$service_file" ]]; then
  existing_service=true
  # Keep operator-managed service definitions at the expected executable path.
  if ! grep -F "$target_binary" "$service_file" >/dev/null; then
    echo "Existing service uses another executable path. Migrate it using the developer guide before proceeding." >&2
    exit 1
  fi
fi
host_target="$HOME/.local/share/nimotehost/nimotehost"
has_desktop=false
if [[ -e "$bundle_dir/host/${app_target##*/}" ]]; then has_desktop=true; fi
is_link_to() {
  [[ -L "$1" ]] && [[ "$(readlink "$1")" == "$2" ]]
}
check_link() {
  if [[ -e "$1" || -L "$1" ]] && ! is_link_to "$1" "$2"; then
    echo "Cannot install the managed link because the path is already in use: $1" >&2
    exit 1
  fi
}
remove_managed_link() {
  if is_link_to "$1" "$2"; then unlink "$1"; fi
}
remove_legacy_app_links() {
  local link
  if [[ "$platform" == Darwin ]]; then
    for link in "${legacy_app_links[@]}"; do
      remove_managed_link "$link" "$legacy_app_target"
    done
  fi
}
if [[ "$mode" == --uninstall ]]; then
  if [[ -x "$host_target" && "$("$host_target" version)" == nimotehost\ *+connect.* ]]; then
    "$source_host" deploy uninstall
  fi
  if [[ -f "$service_file" ]]; then
    [[ -x "$target_binary" ]] || { echo "Connect executable is missing from its installed path." >&2; exit 1; }
    "$target_binary" uninstall
    "$source_binary" stop
  fi
  remove_managed_link "$connect_command" "$target_binary"
  remove_managed_link "$app_link" "$app_target"
  remove_legacy_app_links
  rm -f "$target_binary"
  echo "Uninstalled. Host state and Connect binding retained."
  exit 0
fi

check_link "$connect_command" "$target_binary"
"$source_host" connect-preflight
if "$has_desktop"; then
  mkdir -p "$(dirname "$app_link")"
  check_link "$app_link" "$app_target"
fi
binding="$config_dir/nimote-connect/device-binding.json"
login_required=true
if [[ -f "$binding" ]]; then
  login_required=false
elif [[ "$mode" == --skip-login ]]; then
  echo "No existing binding; run ./install.sh without --skip-login." >&2; exit 1
elif [[ "$mode" == --defer-login ]] || { "$has_desktop" && [[ "$mode" == default ]]; }; then
  login_required=false
fi
backup="$(mktemp -d "$state_dir/backups/install.XXXXXX")"
if [[ -f "$target_binary" ]]; then cp -p "$target_binary" "$backup/nimote-connect"; fi
if "$existing_service"; then cp -p "$service_file" "$backup/service-definition"; fi
was_running=false
if "$existing_service"; then
  if [[ "$platform" == Linux ]]; then
    if systemctl --user is-active --quiet nimote-connect.service; then was_running=true; fi
  elif launchctl print "gui/$(id -u)/com.nimote.connect" >/dev/null 2>&1; then
    was_running=true
  fi
fi
stop_service() {
  if [[ "$platform" == Linux ]]; then
    systemctl --user stop nimote-connect.service || return
  elif launchctl print "gui/$(id -u)/com.nimote.connect" >/dev/null 2>&1; then
    launchctl bootout "gui/$(id -u)/com.nimote.connect" || return
  fi
  # The service manager can return before the old process releases its lock.
  "$source_binary" stop
}
start_existing_service() {
  if [[ "$platform" == Linux ]]; then
    systemctl --user daemon-reload && systemctl --user restart nimote-connect.service
  else
    launchctl bootstrap "gui/$(id -u)" "$service_file"
  fi
}
staged="$(mktemp "$install_dir/.nimote-connect.XXXXXX")"
changed=false
stopped=false
added_command=false
added_app=false
recover() {
  result=$?
  trap - EXIT
  if [[ "$result" != 0 ]] && { "$changed" || "$stopped"; }; then
    restored=true
    if "$changed"; then
      if "$existing_service"; then
        stop_service >/dev/null 2>&1 || restored=false
      elif [[ -f "$service_file" ]]; then
        { "$target_binary" uninstall && "$source_binary" stop; } >/dev/null 2>&1 || restored=false
      fi
      if "$restored"; then
        if [[ -f "$backup/nimote-connect" ]]; then
          { cp -p "$backup/nimote-connect" "$staged" && mv -f "$staged" "$target_binary"; } || restored=false
        else
          rm -f "$target_binary" || restored=false
        fi
        if "$existing_service"; then cp -p "$backup/service-definition" "$service_file" || restored=false; fi
      fi
    fi
    if "$restored" && "$was_running"; then start_existing_service >/dev/null 2>&1 || restored=false; fi
    if "$restored"; then echo "Installation failed; previous Connect files and service state restored." >&2
    else echo "Installation failed; Connect rollback needs attention." >&2; fi
    if "$added_command" && is_link_to "$connect_command" "$target_binary"; then unlink "$connect_command"; fi
    if "$added_app" && is_link_to "$app_link" "$app_target"; then unlink "$app_link"; fi
    echo "Binding retained. Backup: $backup" >&2
  fi
  rm -f "$staged"
  rmdir "$install_lock"
  exit "$result"
}
trap recover EXIT
install -m 755 "$source_binary" "$staged"
if "$existing_service"; then
  stopped=true
  stop_service
fi
changed=true
mv -f "$staged" "$target_binary"
if "$login_required"; then
  echo "Approve the device code in the NimoteCode app to continue."
  "$target_binary" login
fi
if "$existing_service"; then
  start_existing_service
else
  "$target_binary" install
fi

# Wait for local startup before activating Host and the public launchers.
"$target_binary" wait-ready
if [[ ! -L "$connect_command" ]]; then
  ln -s "$target_binary" "$connect_command"
  added_command=true
fi
if "$has_desktop" && [[ ! -L "$app_link" ]]; then
  ln -s "$app_target" "$app_link"
  added_app=true
fi
"$source_host" setup
if ! "$has_desktop"; then remove_managed_link "$app_link" "$app_target"; fi
remove_legacy_app_links
echo "Installed. Host and Connect are running as separate services."
if "$has_desktop"; then
  printf 'Set up the connection: %q gui --connect\n' "$connect_command"
  echo "You can also open $app_link and choose Connect."
else
  if [[ ! -f "$binding" ]]; then printf 'Bind for internet access: %q login\n' "$connect_command"; fi
  printf 'Check internet access: %q remote-access status\n' "$connect_command"
  printf 'To enable it: %q remote-access enable\n' "$connect_command"
fi
echo "Verify your connection by opening a Host session from NimoteCode."
echo "Backup: $backup"
