# Nimote Connect 安装与使用

[English](user-guide.en.md)

## 安装与升级

从发布者取得对应系统和架构的商业包及 SHA-256 校验值。验包后解压，从解压目录以桌面用户运行：

```sh
./install.sh
```

安装包同时安装 Connect 和 Host。macOS 需要已登录的图形用户会话，Linux 需要 systemd 用户会话。已有绑定会自动保留。已有绑定的机器也可显式运行 `./install.sh --skip-login`。首次安装需要在同一控制面的兼容客户端中批准设备码。当前 rc.6 验收使用测试替身模拟设备码批准。

Windows x64 和 ARM64 使用 CLI ZIP。解压后，以当前登录用户在 PowerShell 运行 `.\install.ps1`。已有绑定可加 `-SkipLogin`，卸载用 `-Uninstall`。后台任务在该用户登录时运行。CLI 位于 `%LOCALAPPDATA%\NimoteConnect\nimote-connect.exe`，可用 `remote-access status` 查看状态。启用公网连接前，请启动 Windows OpenSSH Server 并确认它监听 TCP 22，且当前用户可读取主机公钥文件。

已经使用 NimoteHost Community 时，以原来安装 Community 的同一系统用户运行 `./install.sh`。安装器会在设备绑定前检查原 Host 和运行中的任务。任务结束后再重试。标准安装会原地切换到 Connect 管理的 Host，保留历史记录、Host 数据及原有 SSH 入口。升级后继续用 Connect 安装包更新。

升级时从新商业包运行安装器。Host 有活动任务时会拒绝升级。安装失败后可根据输出查阅备份与恢复结果。

## 连接

已有 SSH 或用户自有 Tailscale 的环境，继续通过原 SSH 账户和 Host RPC 连接。SSH 命令路径为 `~/.local/bin/nimotehost`。macOS 桌面版可打开 `~/Applications/NimoteConn.app`，Linux 桌面版可运行 `~/.local/bin/nimoteconn`。

绑定后，在 **NimoteConn → Connect → 公网连接** 点击 **启用公网连接**。状态显示 **已上线** 后，在 NimoteCode 中选择这台电脑。公网连接默认关闭，启用后可走 Tailcat 直连或 DERP 中继。macOS 需要在 **系统设置 → 通用 → 共享** 打开 **远程登录**，Linux 需要启动本机 OpenSSH。首次连接时独立核对 SSH 主机指纹。

## 日常操作

| 操作 | 命令 |
| --- | --- |
| 查看两项服务 | `~/.local/bin/nimoteconnect status` 和 `~/.local/bin/nimoteconnect host status` |
| 复制本地诊断 | `nimoteconnect doctor`，或在 **NimoteConn → Connect** 点击 **复制诊断信息** |
| 查看公网连接 | `nimoteconnect remote-access status` |
| 开启或关闭公网连接 | `nimoteconnect remote-access enable` 或 `nimoteconnect remote-access disable` |
| 重启 Connect | `~/.local/bin/nimoteconnect restart` |
| 卸载两项服务和程序，保留绑定与 Host 数据 | 在商业包解压目录运行 `./install.sh --uninstall` |
| 主动解除 Connect 绑定 | `~/.local/bin/nimoteconnect logout` |

`remote-access status` 会区分已关闭、等待注册和已上线。可以在 NimoteCode 中发起一次连接确认端到端可用。联系支持时仅提供脱敏错误，保护设备绑定、密码及私钥。

NimoteCode 的设备列表显示主机上报的版本，并在离线时显示最近一次上报时间。诊断报告包括本机 Connect 版本、绑定可读性、后台状态、公网注册状态和本机 SSH 端口探测。
