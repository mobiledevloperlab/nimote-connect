# Third-party notices

## Tailcat

Nimote Connect uses transport code from Tailcat `v0.3.0` with local changes for targeted peer
revocation, authenticated region discovery and live DERP route updates. The source and license are in `internal/thirdparty/tailcat`.

Copyright (c) 2020 Tailscale Inc & contributors.

Tailcat is distributed under the BSD 3-Clause License. The applicable license
text is retained with the vendored Host source and must accompany binary releases of
Nimote Connect.

No Tailcat connection metadata, device credential, SSH credential, or network
endpoint is included in this notice.

## Host release license inventory

The Linux host build-linked module versions and root license-file hashes are
recorded in [the audit inventory](https://github.com/mobiledevloperlab/nimote-host/blob/main/docs/audits/evidence/host-linked-modules.json).
This inventory is not a substitute for distributing complete license texts or
reviewing file-level exceptions, platform-specific dependencies and native assets.

### Tailcat BSD-3-Clause license (verbatim)

BSD 3-Clause License

Copyright (c) 2020 Tailscale Inc & contributors.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
