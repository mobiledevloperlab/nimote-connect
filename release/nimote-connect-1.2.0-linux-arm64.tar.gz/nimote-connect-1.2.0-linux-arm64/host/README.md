# NimoteHost 2.5.0+connect.1.2.0

**English** | [简体中文](README.zh-CN.md)

CLI · linux/arm64

The host-side companion to [NimoteCode](https://github.com/mobiledevloperlab/nimotecode).
It also works with scripts and third-party clients. This is a development preview.

## Install

Extract the complete archive and run from this directory as your normal user, without sudo:

```sh
sh scripts/install.sh
```

No Go installation is needed. Setup verifies SHA256SUMS, copies the bundle to a
stable per-user directory and starts the background service. Upgrades preserve
state and credentials and refuse to interrupt active tasks. Keep all bundle files
together; do not remove license files or edit files covered by SHA256SUMS.

For foreground CLI use instead:

```sh
./nimotehost start
```

## Connect and manage

Connect NimoteCode over your existing SSH connection as the same OS user.
SSH and Agent CLIs require separate installation and authentication. Host listens
only on loopback. Client disconnects do not stop tasks; Host/OS restarts do not
restore their processes. Use nimotehost status, stop or restart to manage Host.

## Documentation and notices

- [Full documentation](https://github.com/mobiledevloperlab/nimotehost/blob/master/README.md)
- [Client integration](https://github.com/mobiledevloperlab/nimotehost/blob/master/docs/client-api.md)
- [Security and credential rotation](https://github.com/mobiledevloperlab/nimotehost/blob/master/SECURITY.md)
- [License](LICENSE) · [Notice](NOTICE) · [Third-party notices](THIRD_PARTY_NOTICES.md)

BUILD.json and MODULES.json describe the CLI build. Desktop bundles also carry
GUI-MODULES.json and licenses-gui/. SHA256SUMS covers the bundle; the adjacent
archive .sha256 covers the download. Checksums do not authenticate the publisher.
