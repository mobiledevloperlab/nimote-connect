Run ./install.sh as the signed-in macOS desktop user.
The package installs ~/.local/bin/nimoteconn. Use its host subcommand for Host commands.
Remove both services and executables with ./install.sh --uninstall.
This archive contains CLI tools. Use ./install.sh --defer-login to bind later.
Chinese: docs/guides/user-guide.md ; English: docs/guides/user-guide.en.md
BUILD.json identifies the binary and linked modules. Root license texts are in licenses/.
