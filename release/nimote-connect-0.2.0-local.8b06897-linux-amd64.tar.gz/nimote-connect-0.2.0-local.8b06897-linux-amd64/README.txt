Run ./install.sh as your normal user. Existing binding: ./install.sh --skip-login
Uninstall both services and executables: ./install.sh --uninstall
The package installs the nimoteconnect CLI. Use nimoteconnect host for Host commands.
For desktop packages, open ~/Applications/NimoteConn.app on macOS or run
~/.local/bin/nimoteconn on Linux.
Chinese: docs/guides/user-guide.md ; English: docs/guides/user-guide.en.md
BUILD.json identifies the binary and linked modules. Root license texts are in licenses/.
This bundle is not proof of legal, signing, store or end-to-end acceptance.
