# Install and use Nimote Connect

[中文](user-guide.md)

## Install or upgrade

Obtain the commercial bundle for your platform and the SHA-256 checksum from the distributor. Verify the archive, extract it, and run this command from the extracted directory as your desktop user:

```sh
./install.sh
```

The bundle installs Connect and Host. macOS requires an active desktop login. Linux requires a systemd user session. Upgrades retain an existing binding. Use `./install.sh --skip-login` to require one. A first installation needs a compatible client on the same control plane to approve the device code. The rc.6 acceptance tests used fixture approval.

For Windows x64 or ARM64, extract the CLI ZIP and run `.\install.ps1` in PowerShell as the logged-in user. Use `-SkipLogin` with an existing binding or `-Uninstall` to remove the services. Scheduled tasks run while this user is logged in. The CLI is at `%LOCALAPPDATA%\NimoteConnect\nimote-connect.exe`. Before enabling public remote access, start Windows OpenSSH Server on TCP port 22 and confirm that this user can read its public host keys.

To switch from NimoteHost Community, run `./install.sh` as the same user who installed Community. The installer checks the existing Host and running tasks before requesting pairing. Wait for any running work to finish. A standard installation switches to the Connect-managed Host in place and retains Host data, session history and the existing SSH entry. Use the Connect installer for subsequent updates.

Use the new commercial installer to upgrade. Active Host tasks block replacement. If installation fails, consult the reported backup location and recovery result.

## Connect

Existing SSH and personal Tailscale connections use the same SSH account and Host RPC. The SSH command is available at `~/.local/bin/nimotehost`. Open `~/Applications/NimoteConn.app` on macOS or run `~/.local/bin/nimoteconn` on Linux to launch the desktop app.

After binding, open **NimoteConn → Connect → Remote access** and select **Enable remote access**. Once the status shows **Online**, choose this computer in NimoteCode. Remote access starts off by default. When enabled, it supports direct Tailcat connections and DERP relaying. On macOS, turn on **Remote Login** under **System Settings → General → Sharing**. On Linux, start the local OpenSSH server. Independently confirm the SSH host fingerprint on the first connection.

## Manage the installation

| Action | Command |
| --- | --- |
| Check both services | `~/.local/bin/nimoteconnect status` and `~/.local/bin/nimoteconnect host status` |
| Copy local diagnostics | `nimoteconnect doctor`, or select **Copy diagnostics** in **NimoteConn → Connect** |
| Check remote access | `nimoteconnect remote-access status` |
| Enable or disable remote access | `nimoteconnect remote-access enable` or `nimoteconnect remote-access disable` |
| Restart Connect | `~/.local/bin/nimoteconnect restart` |
| Remove both services and binaries, keeping binding and Host data | Run `./install.sh --uninstall` from the extracted bundle |
| Revoke the local Connect binding | `~/.local/bin/nimoteconnect logout` |

Remote-access status shows whether access is off, awaiting registration, or online. Connect from NimoteCode to verify end-to-end connectivity. Share redacted diagnostics with support and keep passwords, private keys, and device bindings private.

The device list in NimoteCode shows the reported host version and, for an offline device, the last time it reported in. The diagnostics report includes the local Connect version, binding readability, background service state, remote registration and the local SSH port check.
