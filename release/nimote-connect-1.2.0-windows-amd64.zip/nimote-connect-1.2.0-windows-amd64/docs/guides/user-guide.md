# Nimote Connect 安装与使用

[English](user-guide.en.md)

## 安装与升级

从发布者取得对应系统和架构的商业包及 SHA-256 校验值。验包后解压，从解压目录以桌面用户运行：

```sh
./install.sh
```

安装包同时安装 Connect 和 Host。macOS 需要已登录的图形用户会话，Linux 需要 systemd 用户会话。桌面包安装完成后，运行 `~/.local/bin/nimoteconn gui --connect` 选择连接方式。CLI 包首次安装会显示设备码，可用 `--defer-login` 先安装，再使用已有 SSH 或稍后绑定。已有绑定会自动保留，`--skip-login` 可用于要求已有绑定的升级。若希望在桌面包安装期间绑定，可加 `--login`。

Windows x64 和 ARM64 使用 CLI ZIP。解压后，以当前登录用户在 PowerShell 运行 `.\install.ps1`。已有绑定可加 `-SkipLogin`，稍后绑定用 `-DeferLogin`，卸载用 `-Uninstall`。后台任务在该用户登录时运行。CLI 位于 `%LOCALAPPDATA%\NimoteConnect\nimoteconn.exe`。启用公网连接前，请启动 Windows OpenSSH Server，确认它监听 TCP 22，且当前用户可读取主机公钥文件。

已经使用 NimoteHost Community 时，以原来安装 Community 的同一系统用户运行 `./install.sh`。安装器会在设备绑定前检查原 Host 和运行中的任务。任务结束后再重试。标准安装会原地切换到 Connect 管理的 Host，保留历史记录、Host 数据及原有 SSH 入口。升级后继续用 Connect 安装包更新。

升级时从新商业包运行安装器。Host 有活动任务时会拒绝升级。安装失败后可根据输出查阅备份与恢复结果。

## 连接

已有 SSH 或用户自有 Tailscale 的环境，继续通过原 SSH 账户连接。SSH 命令路径为 `~/.local/bin/nimotehost`。macOS 桌面版也可打开 `~/Applications/NimoteConn.app` 后进入「连接」。Linux 的 GUI 入口要求安装含桌面的制品。

要使用公网或同步个人 Tailscale 配置，在桌面「连接」页绑定设备，或运行 `nimoteconn login`，然后在手机上的 NimoteCode 中输入设备码并批准。手机和电脑须使用同一套 Nimote 服务。

公网连接默认关闭。绑定后在 **NimoteConn → 连接 → 公网连接** 启用，或运行 `nimoteconn remote-access enable`。macOS 先在 **系统设置 → 通用 → 共享** 打开 **远程登录**，Linux 先启动本机 OpenSSH。显示 **已向 Nimote 注册** 后，在手机选择这台电脑，独立核对 SSH 主机指纹并打开一个 Host 会话，确认端到端可用。

## 日常操作

| 操作 | 命令 |
| --- | --- |
| 查看两项服务 | `~/.local/bin/nimoteconn status` 和 `~/.local/bin/nimoteconn host status` |
| 查看或复制诊断 | `nimoteconn doctor`，或在 **NimoteConn → 连接** 查看、复制诊断信息 |
| 查看公网连接 | `nimoteconn remote-access status` |
| 开启或关闭公网连接 | `nimoteconn remote-access enable` 或 `nimoteconn remote-access disable` |
| 重启 Connect | `~/.local/bin/nimoteconn restart` |
| 卸载两项服务和程序，保留绑定与 Host 数据 | 在商业包解压目录运行 `./install.sh --uninstall` |
| 主动解除 Connect 绑定 | `~/.local/bin/nimoteconn logout` |

`remote-access status` 会显示公网设置、注册进度和已识别的故障。关闭公网会重启 Connect，可能中断正在使用公网连接的会话。解绑会先停止 Connect，然后请求云端撤销；若结果暂未确认，可重试解绑。卸载会保留绑定和 Host 数据，如需永久停用设备，先完成解绑。

NimoteCode 的设备列表显示主机上报的版本，并在离线时显示最近一次上报时间。诊断报告包括 Connect 与 Host 状态、公网注册状态、当前进程最近一次成功联系云端的时间（如有）和本机 SSH 端口探测。发送给支持前可先在连接页预览报告。
