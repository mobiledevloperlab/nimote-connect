Run .\install.ps1 in PowerShell as the signed-in user.
Bind later with -DeferLogin. Remove the services and executables with -Uninstall.
CLI: %LOCALAPPDATA%\NimoteConnect\nimoteconn.exe
This ZIP contains CLI tools.
Chinese: docs/guides/user-guide.md ; English: docs/guides/user-guide.en.md
BUILD.json identifies the binary and linked modules. Root license texts are in licenses/.
