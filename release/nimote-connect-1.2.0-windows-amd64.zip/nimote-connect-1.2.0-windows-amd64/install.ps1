# Per-user installer for the Windows Nimote Connect bundle.
[CmdletBinding()]
param([switch]$SkipLogin, [switch]$Uninstall, [switch]$Help, [switch]$DeferLogin)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
if ($Help) {
    Write-Output 'Usage: .\install.ps1 [-SkipLogin | -DeferLogin | -Uninstall]'
    return
}
if (($SkipLogin -and $DeferLogin) -or ($Uninstall -and ($SkipLogin -or $DeferLogin))) {
    throw 'Choose one of -SkipLogin, -DeferLogin, or -Uninstall.'
}

function Invoke-Program([string]$Program, [string[]]$Arguments) {
    & $Program @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Failed: $Program $($Arguments -join ' ') (exit $LASTEXITCODE)" }
}

function Move-Executable([string]$From, [string]$To) {
    # Task Scheduler can hold the old image briefly after the daemon lock clears.
    for ($attempt = 0; ; $attempt++) {
        try {
            Move-Item -LiteralPath $From -Destination $To
            return
        } catch {
            if ($attempt -ge 40) { throw }
            Start-Sleep -Milliseconds 250
        }
    }
}

$root = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\') + '\'
$manifest = Join-Path $root 'SHA256SUMS'
$verified = @{}
foreach ($line in Get-Content -LiteralPath $manifest) {
    if ($line -notmatch '^([0-9a-fA-F]{64})  \./([^\\]+)$') { throw 'Invalid SHA256SUMS entry.' }
    $digest, $relative = $Matches[1], $Matches[2]
    $path = [IO.Path]::GetFullPath((Join-Path $root $relative))
    if (-not $path.StartsWith($root, [StringComparison]::OrdinalIgnoreCase) -or $verified.ContainsKey($path)) {
        throw "Unexpected checksum path: $relative"
    }
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $digest) { throw "Checksum mismatch: $relative" }
    $verified[$path] = $true
}
$sourceConnect = Join-Path $root 'nimote-connect.exe'
$sourceHost = Join-Path $root 'host\nimotehost.exe'
foreach ($path in @($sourceConnect, $sourceHost, (Join-Path $root 'host\SHA256SUMS'))) {
    if (-not $verified.ContainsKey($path)) { throw "Missing required bundle checksum: $path" }
}
Invoke-Program $sourceConnect @('version') | Out-Null
if ((Invoke-Program $sourceHost @('version')) -notlike 'nimotehost *+connect.*') { throw 'Invalid commercial Host executable.' }

if (-not $env:LOCALAPPDATA -or -not $env:APPDATA) { throw 'Run as the logged-in desktop user.' }
$destination = Join-Path $env:LOCALAPPDATA 'NimoteConnect'
$installedConnect = Join-Path $destination 'nimoteconn.exe'
$installedHost = Join-Path $env:LOCALAPPDATA 'NimoteHost\nimotehost.exe'
$config = Join-Path $env:APPDATA 'nimote-connect'
$binding = Join-Path $config 'device-binding.json'
$service = Join-Path $config 'service.xml'
New-Item -ItemType Directory -Path $destination -Force | Out-Null
$operationLock = Join-Path $destination 'install.lock'
$lock = [IO.File]::Open($operationLock, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
try {
    $hadBinary = Test-Path -LiteralPath $installedConnect -PathType Leaf
    $hadService = Test-Path -LiteralPath $service -PathType Leaf
    if ($hadService -and -not $hadBinary) { throw 'The existing Connect task has no managed executable.' }
    if ($Uninstall) {
        if ((Test-Path -LiteralPath $installedHost -PathType Leaf) -and
            ((Invoke-Program $installedHost @('version')) -like 'nimotehost *+connect.*')) {
            Invoke-Program $sourceHost @('deploy', 'uninstall')
        }
        if ($hadBinary) {
            Invoke-Program $installedConnect @('uninstall')
            Invoke-Program $installedConnect @('stop')
            $removed = Join-Path $destination ("removed-" + [guid]::NewGuid() + '.exe')
            Move-Executable $installedConnect $removed
            Remove-Item -LiteralPath $removed -Force
        }
        Write-Output 'Uninstalled. Host state and Connect binding retained.'
        return
    }

    Invoke-Program $sourceHost @('connect-preflight')
    $bound = Test-Path -LiteralPath $binding -PathType Leaf
    if ($SkipLogin -and -not $bound) { throw 'No existing binding. Run without -SkipLogin to bind this device.' }
    $wasRunning = $hadBinary -and ((Invoke-Program $installedConnect @('status')) -match '^Status: Running$')
    $backup = Join-Path $destination ("previous-" + [guid]::NewGuid() + '.exe')
    $staged = Join-Path $destination ("staged-" + [guid]::NewGuid() + '.exe')
    $replaced = $false
    try {
        Copy-Item -LiteralPath $sourceConnect -Destination $staged
        if ($hadBinary) {
            Invoke-Program $installedConnect @('stop')
            Move-Executable $installedConnect $backup
        }
        Move-Executable $staged $installedConnect
        $replaced = $true
        if (-not $bound -and -not $DeferLogin) { Invoke-Program $installedConnect @('login') }
        Invoke-Program $installedConnect @('install')
        Invoke-Program $installedConnect @('wait-ready')
        Invoke-Program $sourceHost @('setup')
    } catch {
        $installationError = $_
        try {
            if ($replaced -and (Test-Path -LiteralPath $installedConnect)) {
                if ($hadService) { Invoke-Program $installedConnect @('stop') }
                else { Invoke-Program $installedConnect @('uninstall') }
                $failed = Join-Path $destination ("failed-" + [guid]::NewGuid() + '.exe')
                Move-Executable $installedConnect $failed
                Remove-Item -LiteralPath $failed -Force
            }
            if (Test-Path -LiteralPath $backup) { Move-Executable $backup $installedConnect }
            if ($hadService -and $replaced) {
                Invoke-Program $installedConnect @('install')
                if ($wasRunning) { Invoke-Program $installedConnect @('wait-ready') }
                else { Invoke-Program $installedConnect @('stop') }
            } elseif ($hadService -and $wasRunning) {
                Invoke-Program $installedConnect @('restart')
            }
        } catch {
            throw "Installation failed: $installationError. Rollback also failed: $_"
        }
        throw $installationError
    } finally {
        if (Test-Path -LiteralPath $staged) { Remove-Item -LiteralPath $staged -Force }
    }
    if (Test-Path -LiteralPath $backup) { Remove-Item -LiteralPath $backup -Force }
    Write-Output "Installed Nimote Connect at $installedConnect"
    if (-not (Test-Path -LiteralPath $binding -PathType Leaf)) {
        Write-Output 'Bind for internet access: & "$env:LOCALAPPDATA\NimoteConnect\nimoteconn.exe" login'
    }
    Write-Output 'Check internet access: & "$env:LOCALAPPDATA\NimoteConnect\nimoteconn.exe" remote-access status'
    Write-Output 'To enable it: & "$env:LOCALAPPDATA\NimoteConnect\nimoteconn.exe" remote-access enable'
    Write-Output 'Verify your connection by opening a Host session from NimoteCode.'
} finally {
    $lock.Dispose()
}
